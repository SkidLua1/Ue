import os, sqlite3, secrets, uuid, hmac, hashlib, json
from datetime import datetime, timezone
from contextlib import contextmanager
from urllib.parse import urlparse
from fastapi import FastAPI, Request, HTTPException, Depends, Header, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, HttpUrl, Field, field_validator
from starlette.middleware.sessions import SessionMiddleware

DB=os.getenv('DATABASE_PATH','orders.db')
ADMIN_PASSWORD=os.getenv('ADMIN_PASSWORD','')
CUSTOMER_PASSWORD=os.getenv('CUSTOMER_PASSWORD','')
API_KEY=os.getenv('API_KEY','')
SESSION_SECRET=os.getenv('SESSION_SECRET','')
if not all([ADMIN_PASSWORD,CUSTOMER_PASSWORD,API_KEY,SESSION_SECRET]) or len(SESSION_SECRET)<32:
    raise RuntimeError('Set ADMIN_PASSWORD, CUSTOMER_PASSWORD, API_KEY and SESSION_SECRET (32+ characters) in environment')
app=FastAPI(title='Food Order Management API',version='1.0.0')
app.add_middleware(SessionMiddleware,secret_key=SESSION_SECRET,same_site='lax',https_only=os.getenv('COOKIE_SECURE','false').lower()=='true')
templates=Jinja2Templates(directory=os.path.join(os.path.dirname(__file__),'templates'))

@contextmanager
def connection():
    conn=sqlite3.connect(DB,timeout=20)
    conn.row_factory=sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally: conn.close()

@app.on_event('startup')
def setup():
    with connection() as db:
        db.execute('''CREATE TABLE IF NOT EXISTS orders (id TEXT PRIMARY KEY, owner TEXT NOT NULL, group_url TEXT NOT NULL, status TEXT NOT NULL, subtotal_cents INTEGER, fees_cents INTEGER, discount_cents INTEGER, total_cents INTEGER, currency TEXT DEFAULT 'USD', tracking_url TEXT, provider_order_id TEXT, created_at TEXT NOT NULL)''')
        db.execute('CREATE INDEX IF NOT EXISTS idx_orders_owner ON orders(owner)')

def check_url(url):
    p=urlparse(str(url)); host=(p.hostname or '').lower()
    if p.scheme!='https' or host not in ('www.ubereats.com','ubereats.com','eats.uber.com'):
        raise ValueError('A valid HTTPS Uber Eats link is required')
    return str(url)

class NewOrder(BaseModel):
    group_url:HttpUrl
    owner:str=Field(min_length=1,max_length=80)
    @field_validator('group_url')
    @classmethod
    def validate_link(cls,v): check_url(v); return v
class Quote(BaseModel):
    subtotal_cents:int=Field(ge=0,le=10000000)
    fees_cents:int=Field(ge=0,le=10000000)
    discount_cents:int=Field(ge=0,le=10000000)
class Tracking(BaseModel):
    tracking_url:HttpUrl
    provider_order_id:str=Field(min_length=1,max_length=150)
    @field_validator('tracking_url')
    @classmethod
    def tracking_https(cls,v):
        if v.scheme!='https': raise ValueError('HTTPS required')
        return v

def api_auth(x_api_key:str|None=Header(default=None)):
    if not x_api_key or not secrets.compare_digest(x_api_key,API_KEY): raise HTTPException(401,'Invalid API key')

def get_order(oid):
    with connection() as db: row=db.execute('SELECT * FROM orders WHERE id=?',(oid,)).fetchone()
    if not row: raise HTTPException(404,'Order not found')
    return dict(row)

def create(owner,url):
    check_url(url)
    item={'id':str(uuid.uuid4()),'owner':owner,'group_url':url,'status':'awaiting_quote','created_at':datetime.now(timezone.utc).isoformat()}
    with connection() as db: db.execute('INSERT INTO orders(id,owner,group_url,status,created_at) VALUES (:id,:owner,:group_url,:status,:created_at)',item)
    return get_order(item['id'])

def set_quote(oid,q):
    order=get_order(oid)
    if order['status'] not in ('awaiting_quote','quoted'): raise HTTPException(409,'Cannot quote this order')
    total=q.subtotal_cents+q.fees_cents-q.discount_cents
    if total<0: raise HTTPException(422,'Discount exceeds subtotal and fees')
    with connection() as db:
        db.execute('UPDATE orders SET subtotal_cents=?,fees_cents=?,discount_cents=?,total_cents=?,status=? WHERE id=?',(q.subtotal_cents,q.fees_cents,q.discount_cents,total,'quoted',oid))
    return get_order(oid)

def approve(oid):
    order=get_order(oid)
    if order['status']!='quoted' or order['total_cents'] is None: raise HTTPException(409,'Order must have a quote before approval')
    with connection() as db: db.execute("UPDATE orders SET status='approved_pending_provider' WHERE id=? AND status='quoted'",(oid,))
    return get_order(oid)

def csrf(request):
    token=request.session.get('csrf')
    if not token:
        token=secrets.token_urlsafe(32);request.session['csrf']=token
    return token

def require_csrf(request,token):
    if not token or not secrets.compare_digest(token,request.session.get('csrf','')): raise HTTPException(403,'Invalid form token')

def page_auth(request,admin=False):
    role=request.session.get('role')
    if role not in (('admin',) if admin else ('admin','customer')): raise HTTPException(403,'Please log in with the required role')
    return role

def render(request,name,**ctx): return templates.TemplateResponse(request,name,{'csrf':csrf(request),**ctx})

@app.get('/health')
def health(): return {'ok':True}
@app.post('/api/orders',dependencies=[Depends(api_auth)],status_code=201)
def api_create(data:NewOrder): return create(data.owner,str(data.group_url))
@app.get('/api/orders/{oid}',dependencies=[Depends(api_auth)])
def api_get(oid:str): return get_order(oid)
@app.get('/api/orders',dependencies=[Depends(api_auth)])
def api_list(owner:str|None=None):
    with connection() as db:
        rows=db.execute('SELECT * FROM orders WHERE owner=? ORDER BY created_at DESC',(owner,)).fetchall() if owner else db.execute('SELECT * FROM orders ORDER BY created_at DESC LIMIT 200').fetchall()
    return [dict(x) for x in rows]
@app.post('/api/orders/{oid}/quote',dependencies=[Depends(api_auth)])
def api_quote(oid:str,data:Quote): return set_quote(oid,data)
@app.post('/api/orders/{oid}/approve',dependencies=[Depends(api_auth)])
def api_approve(oid:str): return approve(oid)
@app.post('/api/orders/{oid}/provider-confirm',dependencies=[Depends(api_auth)])
def provider_confirm(oid:str,data:Tracking):
    order=get_order(oid)
    if order['status']!='approved_pending_provider': raise HTTPException(409,'Approval required')
    with connection() as db: db.execute('UPDATE orders SET status=?,tracking_url=?,provider_order_id=? WHERE id=?',('placed',str(data.tracking_url),data.provider_order_id,oid))
    return get_order(oid)

@app.get('/',response_class=HTMLResponse)
def home(request:Request):
    role=request.session.get('role')
    if not role:return RedirectResponse('/login',status_code=303)
    with connection() as db:
        rows=db.execute('SELECT * FROM orders ORDER BY created_at DESC LIMIT 100').fetchall() if role=='admin' else db.execute('SELECT * FROM orders WHERE owner=? ORDER BY created_at DESC LIMIT 100',(request.session['username'],)).fetchall()
    return render(request,'dashboard.html',orders=[dict(x) for x in rows],role=role,user=request.session['username'])
@app.get('/login',response_class=HTMLResponse)
def login_page(request:Request):return render(request,'login.html',error='')
@app.post('/login')
def login(request:Request,username:str=Form(...),password:str=Form(...),token:str=Form(...)):
    require_csrf(request,token)
    if username=='admin' and secrets.compare_digest(password,ADMIN_PASSWORD):role='admin'
    elif username=='customer' and secrets.compare_digest(password,CUSTOMER_PASSWORD):role='customer'
    else:return render(request,'login.html',error='Invalid credentials')
    request.session.clear();request.session.update({'username':username,'role':role});csrf(request)
    return RedirectResponse('/',status_code=303)
@app.post('/logout')
def logout(request:Request,token:str=Form(...)):
    require_csrf(request,token);request.session.clear();return RedirectResponse('/login',status_code=303)
@app.post('/web/orders')
def web_create(request:Request,group_url:str=Form(...),token:str=Form(...)):
    page_auth(request);require_csrf(request,token)
    order=create(request.session['username'],group_url)
    return RedirectResponse('/orders/'+order['id'],status_code=303)
@app.get('/orders/{oid}',response_class=HTMLResponse)
def detail(request:Request,oid:str):
    role=page_auth(request);order=get_order(oid)
    if role!='admin' and order['owner']!=request.session['username']:raise HTTPException(403)
    return render(request,'order.html',order=order,role=role)
@app.post('/web/orders/{oid}/quote')
def web_quote(request:Request,oid:str,subtotal_cents:int=Form(...),fees_cents:int=Form(...),discount_cents:int=Form(...),token:str=Form(...)):
    page_auth(request,admin=True);require_csrf(request,token)
    set_quote(oid,Quote(subtotal_cents=subtotal_cents,fees_cents=fees_cents,discount_cents=discount_cents))
    return RedirectResponse('/orders/'+oid,status_code=303)
@app.post('/web/orders/{oid}/approve')
def web_approve(request:Request,oid:str,token:str=Form(...)):
    role=page_auth(request);require_csrf(request,token)
    order=get_order(oid)
    if role!='admin' and order['owner']!=request.session['username']:raise HTTPException(403)
    approve(oid);return RedirectResponse('/orders/'+oid,status_code=303)
