# Food Order Hub: Customer Website + Admin Dashboard + Discord Bot

A **working local prototype** with shared FastAPI API, SQLite storage, browser-based customer/admin dashboards, Discord slash commands, order quotes, approval, and a provider-confirmation API. **This does not place live Uber Eats orders**, automatically parse Uber Eats group carts, create Uber Eats accounts, retrieve coupons, verify phone numbers, add cards, or retrieve tracking links. Those require supported authorized integrations. No undocumented Uber Eats APIs or anti-abuse evasion are included.

## Start

Requires Python 3.10+.

```bash
cd food_order_platform
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
cp .env.example .env  # Windows: copy .env.example .env
```

Edit `.env` with **strong unique passwords**, a random API key, and a 32+ character random session secret. Load the environment:

```bash
set -a; source .env; set +a  # macOS/Linux
uvicorn app:app --host 127.0.0.1 --port 8000
```

Open http://127.0.0.1:8000 and sign in as `customer` or `admin` with the corresponding configured password. The sample supports one customer login for demonstration; add proper multi-user authentication before exposing it publicly.

To run Discord bot in another terminal, load `.env` again and run `python bot.py`. Configure the bot in the Discord developer portal and invite it with `bot` and `applications.commands` scopes. `/order` creates a session; `/orderstatus` displays it and, after an admin enters a quote, offers an approval button.

## API examples

```bash
curl -X POST http://127.0.0.1:8000/api/orders -H "X-API-Key: $API_KEY" -H 'Content-Type: application/json' -d '{"owner":"123456789","group_url":"https://www.ubereats.com/"}'
# Returns an order id. Replace ORDER_ID below.
curl -X POST http://127.0.0.1:8000/api/orders/ORDER_ID/quote -H "X-API-Key: $API_KEY" -H 'Content-Type: application/json' -d '{"subtotal_cents":2499,"fees_cents":550,"discount_cents":0}'
curl -X POST http://127.0.0.1:8000/api/orders/ORDER_ID/approve -H "X-API-Key: $API_KEY"
```

The `POST /api/orders/{id}/provider-confirm` endpoint accepts `{"provider_order_id":"...","tracking_url":"https://..."}` after approval. **Only a trusted server-side integration should call it following a verified actual purchase**. It currently records supplied provider confirmation; it does not verify it against Uber Eats. Open `/docs` for interactive API documentation.

## Integration architecture

The API is the source of truth for both UIs. Add an authorized checkout provider adapter that (1) retrieves an authentic cart and quote, (2) supports checkout after explicit approval, (3) confirms an actual purchase with a provider order ID, and (4) obtains a genuine tracking link. Never accept raw card numbers/CVVs into this app; use PCI-compliant payment tokens. Do not use proxies or disposable phone numbers to circumvent platform limits, promotions, or account controls.

## Production checklist

**Not production ready.** Before deployment: replace shared customer credentials with individual identities; add proper account ownership to API keys, provider-signed callbacks and idempotency keys; enforce HTTPS and `COOKIE_SECURE=true`; use rate limiting, audit logging, secure secret storage, encrypted backups, and a production database. Do not expose the demo to the public Internet unchanged. No payment is executed by this prototype.
