import os, aiohttp, discord
from discord import app_commands
TOKEN=os.environ['DISCORD_TOKEN']
API=os.getenv('API_BASE_URL','http://127.0.0.1:8000').rstrip('/')
KEY=os.environ['API_KEY']
intents=discord.Intents.default()
client=discord.Client(intents=intents)
tree=app_commands.CommandTree(client)
async def api(method,path,payload=None):
    async with aiohttp.ClientSession(headers={'X-API-Key':KEY}) as session:
        async with session.request(method,API+path,json=payload,timeout=aiohttp.ClientTimeout(total=15)) as response:
            data=await response.json()
            if response.status>=400: raise RuntimeError(str(data.get('detail',data)))
            return data
class Approve(discord.ui.View):
    def __init__(self,oid,owner):
        super().__init__(timeout=900)
        self.oid=oid;self.owner=owner
    @discord.ui.button(label='Approve order',style=discord.ButtonStyle.green)
    async def approve(self,interaction:discord.Interaction,button:discord.ui.Button):
        if str(interaction.user.id)!=self.owner:
            await interaction.response.send_message('Only the order owner can approve.',ephemeral=True);return
        try:
            item=await api('POST',f'/api/orders/{self.oid}/approve')
            await interaction.response.send_message('Approved. Awaiting authorized checkout integration; no charge made.',ephemeral=True)
            self.stop()
        except Exception as exc:await interaction.response.send_message(str(exc),ephemeral=True)
@tree.command(name='order',description='Create a fresh food order session')
@app_commands.describe(group_link='HTTPS Uber Eats group-order link')
async def order(interaction:discord.Interaction,group_link:str):
    await interaction.response.defer(ephemeral=True)
    try:
        item=await api('POST','/api/orders',{'owner':str(interaction.user.id),'group_url':group_link})
        await interaction.followup.send(f"Order `{item['id']}` created. Status: awaiting quote. Check `/orderstatus` for updates.",ephemeral=True)
    except Exception as exc:await interaction.followup.send(str(exc),ephemeral=True)
@tree.command(name='orderstatus',description='Check an order and approve a verified quote')
async def orderstatus(interaction:discord.Interaction,order_id:str):
    await interaction.response.defer(ephemeral=True)
    try:
        item=await api('GET',f'/api/orders/{order_id}')
        if item['owner']!=str(interaction.user.id):
            await interaction.followup.send('This is not your order.',ephemeral=True);return
        msg=f"Order `{order_id}`: **{item['status']}**"
        if item['total_cents'] is not None:msg+=f"\nTotal: **${item['total_cents']/100:.2f}**"
        if item['tracking_url']:msg+=f"\nTracking: {item['tracking_url']}"
        view=Approve(order_id,item['owner']) if item['status']=='quoted' else None
        await interaction.followup.send(msg,view=view,ephemeral=True)
    except Exception as exc:await interaction.followup.send(str(exc),ephemeral=True)
@client.event
async def on_ready():
    await tree.sync();print('Discord bot ready:',client.user)
client.run(TOKEN)
